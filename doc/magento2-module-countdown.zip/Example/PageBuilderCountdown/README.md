This is a countdown timer content type for Page Builder.
![Page Builder Countdown](countdown.png)
